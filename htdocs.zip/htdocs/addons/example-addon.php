<?php

/**
 * Example Add-on for Luna-Dine
 * 
 * This is a sample add-on that demonstrates the add-on system structure.
 * Add-ons can extend functionality without modifying core code.
 */

class ExampleAddon {
    private $db;
    private $config;
    
    public function __construct($db, $config = []) {
        $this->db = $db;
        $this->config = $config;
        
        // Initialize add-on
        $this->init();
    }
    
    private function init() {
        // Add hooks and filters here
        $this->addHooks();
        
        // Create necessary tables if they don't exist
        $this->createTables();
    }
    
    private function addHooks() {
        // Example hooks that can be called from the main system
        add_filter('admin_menu_items', [$this, 'addAdminMenuItem']);
        add_filter('api_endpoints', [$this, 'addApiEndpoints']);
        add_action('before_render', [$this, 'beforeRender']);
        add_action('after_render', [$this, 'afterRender']);
    }
    
    private function createTables() {
        // Create add-on specific tables
        $sql = "CREATE TABLE IF NOT EXISTS example_addon_data (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            value TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        
        try {
            $this->db->execute($sql);
        } catch (Exception $e) {
            error_log("Failed to create example addon table: " . $e->getMessage());
        }
    }
    
    // Hook methods
    public function addAdminMenuItem($items) {
        $items[] = [
            'title' => 'Example Add-on',
            'icon' => 'fas fa-puzzle-piece',
            'url' => '/admin/example-addon',
            'permission' => 'system.addons.manage'
        ];
        return $items;
    }
    
    public function addApiEndpoints($endpoints) {
        $endpoints[] = [
            'method' => 'GET',
            'path' => '/api/example-addon/data',
            'callback' => [$this, 'getAddonData'],
            'permission' => 'system.addons.manage'
        ];
        
        $endpoints[] = [
            'method' => 'POST',
            'path' => '/api/example-addon/data',
            'callback' => [$this, 'saveAddonData'],
            'permission' => 'system.addons.manage'
        ];
        
        return $endpoints;
    }
    
    public function beforeRender() {
        // Code to execute before rendering
        // This can be used to add CSS, JS, or modify data
    }
    
    public function afterRender() {
        // Code to execute after rendering
        // This can be used for cleanup or additional processing
    }
    
    // API Methods
    public function getAddonData($request) {
        try {
            $data = $this->db->fetchAll("SELECT * FROM example_addon_data ORDER BY created_at DESC");
            
            return [
                'success' => true,
                'data' => $data
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    public function saveAddonData($request) {
        try {
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['name']) || !isset($data['value'])) {
                return [
                    'success' => false,
                    'error' => 'Name and value are required'
                ];
            }
            
            $sql = "INSERT INTO example_addon_data (name, value) VALUES (?, ?)";
            $this->db->execute($sql, [$data['name'], $data['value']]);
            
            return [
                'success' => true,
                'message' => 'Data saved successfully'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    // Utility methods
    public function getConfig($key = null) {
        if ($key === null) {
            return $this->config;
        }
        
        return $this->config[$key] ?? null;
    }
    
    public function isActive() {
        return $this->config['status'] === 'active';
    }
    
    public function getVersion() {
        return $this->config['version'] ?? '1.0.0';
    }
    
    public function getName() {
        return $this->config['name'] ?? 'Example Add-on';
    }
    
    // Activation method
    public function activate() {
        // Code to run when add-on is activated
        $this->createTables();
        
        // Add any default data
        $this->addDefaultData();
        
        return true;
    }
    
    // Deactivation method
    public function deactivate() {
        // Code to run when add-on is deactivated
        // Clean up if necessary, but preserve data
        return true;
    }
    
    // Uninstall method
    public function uninstall() {
        // Code to run when add-on is uninstalled
        // Remove tables and data
        try {
            $this->db->execute("DROP TABLE IF EXISTS example_addon_data");
            return true;
        } catch (Exception $e) {
            error_log("Failed to uninstall example addon: " . $e->getMessage());
            return false;
        }
    }
    
    private function addDefaultData() {
        // Add some default data for demonstration
        $defaultData = [
            ['welcome_message', 'Welcome to Example Add-on!'],
            ['feature_enabled', '1'],
            ['setting_value', 'default']
        ];
        
        foreach ($defaultData as $data) {
            try {
                $this->db->execute(
                    "INSERT INTO example_addon_data (name, value) VALUES (?, ?)",
                    $data
                );
            } catch (Exception $e) {
                // Ignore if data already exists
            }
        }
    }
}

// Hook system functions (simplified)
if (!function_exists('add_filter')) {
    function add_filter($hook, $callback, $priority = 10) {
        global $filters;
        if (!isset($filters[$hook])) {
            $filters[$hook] = [];
        }
        $filters[$hook][$priority] = $callback;
    }
}

if (!function_exists('add_action')) {
    function add_action($hook, $callback, $priority = 10) {
        add_filter($hook, $callback, $priority);
    }
}

if (!function_exists('apply_filters')) {
    function apply_filters($hook, $value) {
        global $filters;
        if (isset($filters[$hook])) {
            ksort($filters[$hook]);
            foreach ($filters[$hook] as $callback) {
                $value = call_user_func($callback, $value);
            }
        }
        return $value;
    }
}

if (!function_exists('do_action')) {
    function do_action($hook, $args = []) {
        global $filters;
        if (isset($filters[$hook])) {
            ksort($filters[$hook]);
            foreach ($filters[$hook] as $callback) {
                call_user_func($callback, $args);
            }
        }
    }
}

// Add-on initialization
function initExampleAddon() {
    global $db;
    
    // Check if add-on is active
    try {
        $config = $db->fetch("SELECT * FROM addons WHERE slug = 'example-addon' AND status = 'active'");
        
        if ($config) {
            $addon = new ExampleAddon($db, $config);
            
            // Activate if newly installed
            if ($config['status'] === 'installed') {
                $addon->activate();
                $db->execute("UPDATE addons SET status = 'active' WHERE id = ?", [$config['id']]);
            }
            
            return $addon;
        }
    } catch (Exception $e) {
        error_log("Failed to initialize example addon: " . $e->getMessage());
    }
    
    return null;
}

// Initialize the add-on
$exampleAddon = initExampleAddon();

?>