<?php

// VERSION: 1.0 - Admin API for Luna-Dine System

declare(strict_types=1);

/**
 * Admin API for Luna-Dine Restaurant Management System
 * 
 * Complete admin API with authentication, authorization, and role-based access control
 * Compatible with the provided database schema
 */

// Prevent direct access
if (!defined('APP_PATH')) {
    define('APP_PATH', dirname(__DIR__));
}

// Load configuration and database
require_once __DIR__ . '/../config/config.php';
Config::load();

require_once __DIR__ . '/../config/database.php';

// Set JSON response headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('X-API-Version: 1.0');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Simple authentication middleware
function authenticate() {
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? null;
    
    if (!$token || !str_starts_with($token, 'Bearer ')) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'Authentication required'
        ]);
        exit;
    }
    
    $token = substr($token, 7);
    
    try {
        $db = Database::getInstance();
        $session = $db->fetch(
            "SELECT s.*, u.*, r.* 
             FROM admin_sessions s 
             JOIN users u ON s.user_id = u.id 
             LEFT JOIN role_permissions r ON u.role = r.role 
             WHERE s.session_token = ? AND s.is_active = 1 AND s.expires_at > NOW()",
            [$token]
        );
        
        if (!$session) {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'error' => 'Invalid or expired token'
            ]);
            exit;
        }
        
        // Update last activity
        $db->execute(
            "UPDATE admin_sessions SET last_activity = NOW() WHERE session_token = ?",
            [$token]
        );
        
        return $session;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Authentication error'
        ]);
        exit;
    }
}

// Authorization middleware
function authorize($permission_code, $user_role) {
    // Super admin has all permissions
    if ($user_role === 'super_admin') {
        return true;
    }
    
    try {
        $db = Database::getInstance();
        $has_permission = $db->fetchColumn(
            "SELECT COUNT(*) FROM role_permissions rp 
             JOIN admin_permissions p ON rp.permission_id = p.id 
             WHERE rp.role = ? AND p.code = ?",
            [$user_role, $permission_code]
        );
        
        return $has_permission > 0;
    } catch (Exception $e) {
        return false;
    }
}

// Log admin activity
function logActivity($user_id, $action, $description = null, $target_type = null, $target_id = null, $old_values = null, $new_values = null) {
    try {
        $db = Database::getInstance();
        $db->execute(
            "INSERT INTO admin_activity_log (user_id, action, description, target_type, target_id, old_values, new_values, ip_address, user_agent) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $user_id,
                $action,
                $description,
                $target_type,
                $target_id,
                $old_values ? json_encode($old_values) : null,
                $new_values ? json_encode($new_values) : null,
                $_SERVER['REMOTE_ADDR'] ?? null,
                $_SERVER['HTTP_USER_AGENT'] ?? null
            ]
        );
    } catch (Exception $e) {
        // Log error but don't fail the request
        error_log("Failed to log activity: " . $e->getMessage());
    }
}

// Get the request path
$request_uri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($request_uri, PHP_URL_PATH) ?: '/';

// Simple path routing - extract endpoint after /api/admin/
$endpoint = '';
$id = null;
$action = null;

// Remove /qrmenu/api/admin/ prefix if present
if (strpos($path, '/qrmenu/api/admin/') === 0) {
    $path = substr($path, strlen('/qrmenu/api/admin/'));
} elseif (strpos($path, '/api/admin/') === 0) {
    $path = substr($path, strlen('/api/admin/'));
}

// Parse endpoint, ID, and action
$path_parts = array_filter(explode('/', trim($path, '/')));
if (!empty($path_parts)) {
    $endpoint = array_shift($path_parts);
    if (!empty($path_parts)) {
        $id = array_shift($path_parts);
    }
    if (!empty($path_parts)) {
        $action = array_shift($path_parts);
    }
}

// Build API path
$api_path = '/' . $endpoint;
if ($id !== null) {
    $api_path .= '/' . $id;
}
if ($action !== null) {
    $api_path .= '/' . $action;
}

// Public endpoints (no authentication required)
$public_endpoints = ['/login', '/logout'];

// Route requests
switch ($api_path) {
    case '/login':
        handleLogin();
        break;
        
    case '/logout':
        handleLogout();
        break;
        
    case '/':
    case '':
        // API root - show available endpoints
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'message' => 'Luna-Dine Admin API',
            'version' => '1.0',
            'endpoints' => [
                'POST /api/admin/login' => 'Admin login',
                'POST /api/admin/logout' => 'Admin logout',
                'GET /api/admin/dashboard' => 'Get dashboard data',
                'GET /api/admin/users' => 'Get users',
                'POST /api/admin/users' => 'Create user',
                'GET /api/admin/users/{id}' => 'Get user details',
                'PUT /api/admin/users/{id}' => 'Update user',
                'DELETE /api/admin/users/{id}' => 'Delete user',
                'GET /api/admin/branches' => 'Get branches',
                'POST /api/admin/branches' => 'Create branch',
                'GET /api/admin/branches/{id}' => 'Get branch details',
                'PUT /api/admin/branches/{id}' => 'Update branch',
                'DELETE /api/admin/branches/{id}' => 'Delete branch',
                'GET /api/admin/menu-categories' => 'Get menu categories',
                'POST /api/admin/menu-categories' => 'Create menu category',
                'GET /api/admin/menu-categories/{id}' => 'Get menu category details',
                'PUT /api/admin/menu-categories/{id}' => 'Update menu category',
                'DELETE /api/admin/menu-categories/{id}' => 'Delete menu category',
                'GET /api/admin/menu-items' => 'Get menu items',
                'POST /api/admin/menu-items' => 'Create menu item',
                'GET /api/admin/menu-items/{id}' => 'Get menu item details',
                'PUT /api/admin/menu-items/{id}' => 'Update menu item',
                'DELETE /api/admin/menu-items/{id}' => 'Delete menu item',
                'GET /api/admin/orders' => 'Get orders',
                'GET /api/admin/orders/{id}' => 'Get order details',
                'PUT /api/admin/orders/{id}/status' => 'Update order status',
                'GET /api/admin/settings' => 'Get system settings',
                'PUT /api/admin/settings' => 'Update system settings',
                'GET /api/admin/addons' => 'Get add-ons',
                'POST /api/admin/addons' => 'Install add-on',
                'PUT /api/admin/addons/{id}/toggle' => 'Toggle add-on status',
                'DELETE /api/admin/addons/{id}' => 'Uninstall add-on',
                'GET /api/admin/themes' => 'Get themes',
                'POST /api/admin/themes' => 'Install theme',
                'PUT /api/admin/themes/{id}/activate' => 'Activate theme',
                'DELETE /api/admin/themes/{id}' => 'Uninstall theme',
                'GET /api/admin/feature-flags' => 'Get feature flags',
                'PUT /api/admin/feature-flags/{id}' => 'Update feature flag',
                'GET /api/admin/activity-logs' => 'Get activity logs',
                'GET /api/admin/notifications' => 'Get notifications',
                'PUT /api/admin/notifications/{id}/read' => 'Mark notification as read',
                'GET /api/admin/backups' => 'Get backups',
                'POST /api/admin/backups' => 'Create backup',
                'GET /api/admin/permissions' => 'Get permissions',
                'GET /api/admin/stats' => 'Get system statistics'
            ]
        ]);
        break;

    default:
        // Authenticate for all other endpoints
        if (!in_array($api_path, $public_endpoints)) {
            $user = authenticate();
        }
        
        switch ($api_path) {
            case '/dashboard':
                handleDashboard($user);
                break;
                
            case '/users':
                handleUsers($user);
                break;
                
            case '/users/' . $id:
                handleUserDetails($user, $id);
                break;
                
            case '/branches':
                handleBranches($user);
                break;
                
            case '/branches/' . $id:
                handleBranchDetails($user, $id);
                break;
                
            case '/menu-categories':
                handleMenuCategories($user);
                break;
                
            case '/menu-categories/' . $id:
                handleMenuCategoryDetails($user, $id);
                break;
                
            case '/menu-items':
                handleMenuItems($user);
                break;
                
            case '/menu-items/' . $id:
                handleMenuItemDetails($user, $id);
                break;
                
            case '/orders':
                handleOrders($user);
                break;
                
            case '/orders/' . $id . '/status':
                handleOrderStatusUpdate($user, $id);
                break;
                
            case '/settings':
                handleSettings($user);
                break;
                
            case '/addons':
                handleAddons($user);
                break;
                
            case '/addons/' . $id . '/toggle':
                handleAddonToggle($user, $id);
                break;
                
            case '/themes':
                handleThemes($user);
                break;
                
            case '/themes/' . $id . '/activate':
                handleThemeActivate($user, $id);
                break;
                
            case '/feature-flags':
                handleFeatureFlags($user);
                break;
                
            case '/activity-logs':
                handleActivityLogs($user);
                break;
                
            case '/notifications':
                handleNotifications($user);
                break;
                
            case '/notifications/' . $id . '/read':
                handleNotificationRead($user, $id);
                break;
                
            case '/backups':
                handleBackups($user);
                break;
                
            case '/permissions':
                handlePermissions($user);
                break;
                
            case '/stats':
                handleStats($user);
                break;
                
            default:
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Endpoint not found',
                    'path' => $api_path
                ]);
                break;
        }
        break;
}

// Handler Functions
function handleLogin() {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data || !isset($data['username']) || !isset($data['password'])) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => 'Username and password required'
            ]);
            return;
        }
        
        $db = Database::getInstance();
        
        // Check if user exists and is active
        $user = $db->fetch(
            "SELECT * FROM users WHERE username = ? AND status = 'active'",
            [$data['username']]
        );
        
        if (!$user) {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'error' => 'Invalid credentials'
            ]);
            return;
        }
        
        // Check if account is locked
        if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'error' => 'Account locked. Try again later.'
            ]);
            return;
        }
        
        // Verify password
        if (!password_verify($data['password'], $user['password_hash'])) {
            // Increment login attempts
            $attempts = $user['login_attempts'] + 1;
            $lock_until = null;
            
            if ($attempts >= 5) {
                $lock_until = date('Y-m-d H:i:s', strtotime('+15 minutes'));
            }
            
            $db->execute(
                "UPDATE users SET login_attempts = ?, locked_until = ? WHERE id = ?",
                [$attempts, $lock_until, $user['id']]
            );
            
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'error' => 'Invalid credentials'
            ]);
            return;
        }
        
        // Reset login attempts
        $db->execute(
            "UPDATE users SET login_attempts = 0, locked_until = NULL, last_login = NOW() WHERE id = ?",
            [$user['id']]
        );
        
        // Generate session token
        $session_token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        // Create session
        $db->execute(
            "INSERT INTO admin_sessions (user_id, session_token, ip_address, user_agent, expires_at) 
             VALUES (?, ?, ?, ?, ?)",
            [
                $user['id'],
                $session_token,
                $_SERVER['REMOTE_ADDR'] ?? null,
                $_SERVER['HTTP_USER_AGENT'] ?? null,
                $expires_at
            ]
        );
        
        // Log activity
        logActivity($user['id'], 'login', 'User logged in to admin panel');
        
        echo json_encode([
            'success' => true,
            'message' => 'Login successful',
            'data' => [
                'token' => $session_token,
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'full_name' => $user['full_name'],
                    'email' => $user['email'],
                    'role' => $user['role'],
                    'branch_id' => $user['branch_id']
                ]
            ]
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleLogout() {
    try {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? null;
        
        if ($token && str_starts_with($token, 'Bearer ')) {
            $token = substr($token, 7);
            
            $db = Database::getInstance();
            $session = $db->fetch(
                "SELECT * FROM admin_sessions WHERE session_token = ?",
                [$token]
            );
            
            if ($session) {
                // Deactivate session
                $db->execute(
                    "UPDATE admin_sessions SET is_active = 0 WHERE session_token = ?",
                    [$token]
                );
                
                // Log activity
                logActivity($session['user_id'], 'logout', 'User logged out of admin panel');
            }
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Logout successful'
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleDashboard($user) {
    if (!authorize('dashboard.view', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        // Get basic statistics
        $stats = [];
        
        // Total branches
        $stats['total_branches'] = $db->fetchColumn("SELECT COUNT(*) FROM branches WHERE status = 'active'");
        
        // Total users
        $stats['total_users'] = $db->fetchColumn("SELECT COUNT(*) FROM users WHERE status = 'active'");
        
        // Total orders today
        $stats['orders_today'] = $db->fetchColumn(
            "SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()"
        );
        
        // Total revenue today
        $stats['revenue_today'] = $db->fetchColumn(
            "SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE DATE(created_at) = CURDATE() AND payment_status = 'paid'"
        );
        
        // Recent orders
        $recent_orders = $db->fetchAll(
            "SELECT o.*, b.name as branch_name, t.table_number 
             FROM orders o 
             LEFT JOIN branches b ON o.branch_id = b.id 
             LEFT JOIN tables t ON o.table_id = t.id 
             ORDER BY o.created_at DESC LIMIT 10"
        );
        
        // Recent activity
        $recent_activity = $db->fetchAll(
            "SELECT al.*, u.full_name, u.username 
             FROM admin_activity_log al 
             LEFT JOIN users u ON al.user_id = u.id 
             ORDER BY al.created_at DESC LIMIT 10"
        );
        
        // System notifications
        $notifications = $db->fetchAll(
            "SELECT * FROM admin_notifications 
             WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0 
             ORDER BY created_at DESC LIMIT 5",
            [$user['id']]
        );
        
        echo json_encode([
            'success' => true,
            'data' => [
                'stats' => $stats,
                'recent_orders' => $recent_orders,
                'recent_activity' => $recent_activity,
                'notifications' => $notifications
            ]
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleUsers($user) {
    if (!authorize('users.view', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!authorize('users.create', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Create new user
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['username']) || !isset($data['password']) || !isset($data['full_name']) || !isset($data['role'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Missing required fields: username, password, full_name, role'
                ]);
                return;
            }
            
            // Check if username already exists
            $existing_user = $db->fetch("SELECT id FROM users WHERE username = ?", [$data['username']]);
            if ($existing_user) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Username already exists'
                ]);
                return;
            }
            
            // Hash password
            $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
            
            // Insert user
            $sql = "INSERT INTO users (username, email, phone, password_hash, full_name, role, branch_id, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'active')";
            
            $params = [
                $data['username'],
                $data['email'] ?? null,
                $data['phone'] ?? null,
                $password_hash,
                $data['full_name'],
                $data['role'],
                $data['branch_id'] ?? null
            ];
            
            $db->execute($sql, $params);
            $user_id = $db->lastInsertId();
            
            // Log activity
            logActivity($user['id'], 'user_created', 'Created new user: ' . $data['username'], 'user', $user_id);
            
            echo json_encode([
                'success' => true,
                'message' => 'User created successfully',
                'data' => ['id' => $user_id]
            ]);
            
        } else {
            // Get users
            $page = $_GET['page'] ?? 1;
            $limit = $_GET['limit'] ?? 20;
            $offset = ($page - 1) * $limit;
            
            $sql = "SELECT u.*, b.name as branch_name 
                    FROM users u 
                    LEFT JOIN branches b ON u.branch_id = b.id 
                    WHERE 1=1";
            $params = [];
            
            // Filter by role if specified
            if (isset($_GET['role'])) {
                $sql .= " AND u.role = ?";
                $params[] = $_GET['role'];
            }
            
            // Hide super admin from non-super admin users
            if ($user['role'] !== 'super_admin') {
                $sql .= " AND u.role != 'super_admin'";
            }
            
            $sql .= " ORDER BY u.created_at DESC LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            
            $users = $db->fetchAll($sql, $params);
            
            // Get total count
            $count_sql = "SELECT COUNT(*) FROM users WHERE 1=1";
            $count_params = [];
            
            if (isset($_GET['role'])) {
                $count_sql .= " AND role = ?";
                $count_params[] = $_GET['role'];
            }
            
            if ($user['role'] !== 'super_admin') {
                $count_sql .= " AND role != 'super_admin'";
            }
            
            $total = $db->fetchColumn($count_sql, $count_params);
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'users' => $users,
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $total,
                        'pages' => ceil($total / $limit)
                    ]
                ]
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleUserDetails($user, $id) {
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            if (!authorize('users.edit', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Update user
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No data provided'
                ]);
                return;
            }
            
            // Get current user data
            $current_user = $db->fetch("SELECT * FROM users WHERE id = ?", [$id]);
            if (!$current_user) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'User not found'
                ]);
                return;
            }
            
            // Build update query
            $update_fields = [];
            $params = [];
            
            $allowed_fields = ['username', 'email', 'phone', 'full_name', 'role', 'branch_id', 'status'];
            
            foreach ($allowed_fields as $field) {
                if (isset($data[$field])) {
                    $update_fields[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }
            
            // Update password if provided
            if (isset($data['password']) && !empty($data['password'])) {
                $update_fields[] = "password_hash = ?";
                $params[] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            
            if (empty($update_fields)) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No valid fields to update'
                ]);
                return;
            }
            
            $sql = "UPDATE users SET " . implode(', ', $update_fields) . " WHERE id = ?";
            $params[] = $id;
            
            $db->execute($sql, $params);
            
            // Log activity
            logActivity($user['id'], 'user_updated', 'Updated user: ' . $current_user['username'], 'user', $id, $current_user, $data);
            
            echo json_encode([
                'success' => true,
                'message' => 'User updated successfully'
            ]);
            
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            if (!authorize('users.delete', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Delete user
            $current_user = $db->fetch("SELECT * FROM users WHERE id = ?", [$id]);
            if (!$current_user) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'User not found'
                ]);
                return;
            }
            
            // Don't allow deleting super admin
            if ($current_user['role'] === 'super_admin') {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Cannot delete super admin'
                ]);
                return;
            }
            
            $db->execute("DELETE FROM users WHERE id = ?", [$id]);
            
            // Log activity
            logActivity($user['id'], 'user_deleted', 'Deleted user: ' . $current_user['username'], 'user', $id, $current_user);
            
            echo json_encode([
                'success' => true,
                'message' => 'User deleted successfully'
            ]);
            
        } else {
            // Get user details
            if (!authorize('users.view', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            $user_data = $db->fetch(
                "SELECT u.*, b.name as branch_name 
                 FROM users u 
                 LEFT JOIN branches b ON u.branch_id = b.id 
                 WHERE u.id = ?",
                [$id]
            );
            
            if (!$user_data) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'User not found'
                ]);
                return;
            }
            
            // Hide super admin from non-super admin users
            if ($user_data['role'] === 'super_admin' && $user['role'] !== 'super_admin') {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'User not found'
                ]);
                return;
            }
            
            echo json_encode([
                'success' => true,
                'data' => $user_data
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleBranches($user) {
    if (!authorize('branches.view', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!authorize('branches.create', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Create new branch
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['name']) || !isset($data['branch_code']) || !isset($data['address'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Missing required fields: name, branch_code, address'
                ]);
                return;
            }
            
            $sql = "INSERT INTO branches (headquarters_id, name, branch_code, address, district, area, phone, email, manager_name, capacity, opening_time, closing_time, status, latitude, longitude, settings) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $params = [
                $data['headquarters_id'] ?? 1,
                $data['name'],
                $data['branch_code'],
                $data['address'],
                $data['district'] ?? '',
                $data['area'] ?? '',
                $data['phone'] ?? '',
                $data['email'] ?? null,
                $data['manager_name'] ?? null,
                $data['capacity'] ?? 50,
                $data['opening_time'] ?? '10:00:00',
                $data['closing_time'] ?? '22:00:00',
                $data['status'] ?? 'active',
                $data['latitude'] ?? null,
                $data['longitude'] ?? null,
                $data['settings'] ? json_encode($data['settings']) : null
            ];
            
            $db->execute($sql, $params);
            $branch_id = $db->lastInsertId();
            
            // Log activity
            logActivity($user['id'], 'branch_created', 'Created new branch: ' . $data['name'], 'branch', $branch_id);
            
            echo json_encode([
                'success' => true,
                'message' => 'Branch created successfully',
                'data' => ['id' => $branch_id]
            ]);
            
        } else {
            // Get branches
            $page = $_GET['page'] ?? 1;
            $limit = $_GET['limit'] ?? 20;
            $offset = ($page - 1) * $limit;
            
            $sql = "SELECT b.*, h.name as headquarters_name 
                    FROM branches b 
                    LEFT JOIN headquarters h ON b.headquarters_id = h.id 
                    WHERE 1=1";
            $params = [];
            
            // Filter by status if specified
            if (isset($_GET['status'])) {
                $sql .= " AND b.status = ?";
                $params[] = $_GET['status'];
            }
            
            $sql .= " ORDER BY b.name LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            
            $branches = $db->fetchAll($sql, $params);
            
            // Get total count
            $count_sql = "SELECT COUNT(*) FROM branches WHERE 1=1";
            $count_params = [];
            
            if (isset($_GET['status'])) {
                $count_sql .= " AND status = ?";
                $count_params[] = $_GET['status'];
            }
            
            $total = $db->fetchColumn($count_sql, $count_params);
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'branches' => $branches,
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $total,
                        'pages' => ceil($total / $limit)
                    ]
                ]
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleBranchDetails($user, $id) {
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            if (!authorize('branches.edit', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Update branch
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No data provided'
                ]);
                return;
            }
            
            // Get current branch data
            $current_branch = $db->fetch("SELECT * FROM branches WHERE id = ?", [$id]);
            if (!$current_branch) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Branch not found'
                ]);
                return;
            }
            
            // Build update query
            $update_fields = [];
            $params = [];
            
            $allowed_fields = ['headquarters_id', 'name', 'branch_code', 'address', 'district', 'area', 'phone', 'email', 'manager_name', 'capacity', 'opening_time', 'closing_time', 'status', 'latitude', 'longitude'];
            
            foreach ($allowed_fields as $field) {
                if (isset($data[$field])) {
                    $update_fields[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }
            
            // Update settings if provided
            if (isset($data['settings'])) {
                $update_fields[] = "settings = ?";
                $params[] = json_encode($data['settings']);
            }
            
            if (empty($update_fields)) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No valid fields to update'
                ]);
                return;
            }
            
            $sql = "UPDATE branches SET " . implode(', ', $update_fields) . " WHERE id = ?";
            $params[] = $id;
            
            $db->execute($sql, $params);
            
            // Log activity
            logActivity($user['id'], 'branch_updated', 'Updated branch: ' . $current_branch['name'], 'branch', $id, $current_branch, $data);
            
            echo json_encode([
                'success' => true,
                'message' => 'Branch updated successfully'
            ]);
            
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            if (!authorize('branches.delete', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Delete branch
            $current_branch = $db->fetch("SELECT * FROM branches WHERE id = ?", [$id]);
            if (!$current_branch) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Branch not found'
                ]);
                return;
            }
            
            $db->execute("DELETE FROM branches WHERE id = ?", [$id]);
            
            // Log activity
            logActivity($user['id'], 'branch_deleted', 'Deleted branch: ' . $current_branch['name'], 'branch', $id, $current_branch);
            
            echo json_encode([
                'success' => true,
                'message' => 'Branch deleted successfully'
            ]);
            
        } else {
            // Get branch details
            if (!authorize('branches.view', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            $branch = $db->fetch(
                "SELECT b.*, h.name as headquarters_name 
                 FROM branches b 
                 LEFT JOIN headquarters h ON b.headquarters_id = h.id 
                 WHERE b.id = ?",
                [$id]
            );
            
            if (!$branch) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Branch not found'
                ]);
                return;
            }
            
            echo json_encode([
                'success' => true,
                'data' => $branch
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleMenuCategories($user) {
    if (!authorize('menu.categories.view', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!authorize('menu.categories.create', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Create new menu category
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['name']) || !isset($data['name_bn'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Missing required fields: name, name_bn'
                ]);
                return;
            }
            
            $sql = "INSERT INTO menu_categories (name, name_bn, description, description_bn, image, display_order, is_active) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            $params = [
                $data['name'],
                $data['name_bn'],
                $data['description'] ?? null,
                $data['description_bn'] ?? null,
                $data['image'] ?? null,
                $data['display_order'] ?? 0,
                $data['is_active'] ?? 1
            ];
            
            $db->execute($sql, $params);
            $category_id = $db->lastInsertId();
            
            // Log activity
            logActivity($user['id'], 'menu_category_created', 'Created new menu category: ' . $data['name'], 'menu_category', $category_id);
            
            echo json_encode([
                'success' => true,
                'message' => 'Menu category created successfully',
                'data' => ['id' => $category_id]
            ]);
            
        } else {
            // Get menu categories
            $page = $_GET['page'] ?? 1;
            $limit = $_GET['limit'] ?? 20;
            $offset = ($page - 1) * $limit;
            
            $sql = "SELECT * FROM menu_categories WHERE 1=1";
            $params = [];
            
            // Filter by active status if specified
            if (isset($_GET['is_active'])) {
                $sql .= " AND is_active = ?";
                $params[] = $_GET['is_active'];
            }
            
            $sql .= " ORDER BY display_order, name LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            
            $categories = $db->fetchAll($sql, $params);
            
            // Get total count
            $count_sql = "SELECT COUNT(*) FROM menu_categories WHERE 1=1";
            $count_params = [];
            
            if (isset($_GET['is_active'])) {
                $count_sql .= " AND is_active = ?";
                $count_params[] = $_GET['is_active'];
            }
            
            $total = $db->fetchColumn($count_sql, $count_params);
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'categories' => $categories,
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $total,
                        'pages' => ceil($total / $limit)
                    ]
                ]
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleMenuCategoryDetails($user, $id) {
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            if (!authorize('menu.categories.edit', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Update menu category
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No data provided'
                ]);
                return;
            }
            
            // Get current category data
            $current_category = $db->fetch("SELECT * FROM menu_categories WHERE id = ?", [$id]);
            if (!$current_category) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Menu category not found'
                ]);
                return;
            }
            
            // Build update query
            $update_fields = [];
            $params = [];
            
            $allowed_fields = ['name', 'name_bn', 'description', 'description_bn', 'image', 'display_order', 'is_active'];
            
            foreach ($allowed_fields as $field) {
                if (isset($data[$field])) {
                    $update_fields[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }
            
            if (empty($update_fields)) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No valid fields to update'
                ]);
                return;
            }
            
            $sql = "UPDATE menu_categories SET " . implode(', ', $update_fields) . " WHERE id = ?";
            $params[] = $id;
            
            $db->execute($sql, $params);
            
            // Log activity
            logActivity($user['id'], 'menu_category_updated', 'Updated menu category: ' . $current_category['name'], 'menu_category', $id, $current_category, $data);
            
            echo json_encode([
                'success' => true,
                'message' => 'Menu category updated successfully'
            ]);
            
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            if (!authorize('menu.categories.delete', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Delete menu category
            $current_category = $db->fetch("SELECT * FROM menu_categories WHERE id = ?", [$id]);
            if (!$current_category) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Menu category not found'
                ]);
                return;
            }
            
            $db->execute("DELETE FROM menu_categories WHERE id = ?", [$id]);
            
            // Log activity
            logActivity($user['id'], 'menu_category_deleted', 'Deleted menu category: ' . $current_category['name'], 'menu_category', $id, $current_category);
            
            echo json_encode([
                'success' => true,
                'message' => 'Menu category deleted successfully'
            ]);
            
        } else {
            // Get menu category details
            if (!authorize('menu.categories.view', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            $category = $db->fetch("SELECT * FROM menu_categories WHERE id = ?", [$id]);
            
            if (!$category) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Menu category not found'
                ]);
                return;
            }
            
            echo json_encode([
                'success' => true,
                'data' => $category
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleMenuItems($user) {
    if (!authorize('menu.items.view', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!authorize('menu.items.create', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Create new menu item
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['name']) || !isset($data['name_bn']) || !isset($data['category_id']) || !isset($data['price'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Missing required fields: name, name_bn, category_id, price'
                ]);
                return;
            }
            
            $sql = "INSERT INTO menu_items (category_id, name, name_bn, description, description_bn, price, discount_price, image, preparation_time, is_spicy, is_available, is_popular, is_vegetarian, calories, ingredients) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $params = [
                $data['category_id'],
                $data['name'],
                $data['name_bn'],
                $data['description'] ?? null,
                $data['description_bn'] ?? null,
                $data['price'],
                $data['discount_price'] ?? null,
                $data['image'] ?? null,
                $data['preparation_time'] ?? 15,
                $data['is_spicy'] ?? 'none',
                $data['is_available'] ?? 1,
                $data['is_popular'] ?? 0,
                $data['is_vegetarian'] ?? 0,
                $data['calories'] ?? null,
                $data['ingredients'] ? json_encode($data['ingredients']) : null
            ];
            
            $db->execute($sql, $params);
            $item_id = $db->lastInsertId();
            
            // Log activity
            logActivity($user['id'], 'menu_item_created', 'Created new menu item: ' . $data['name'], 'menu_item', $item_id);
            
            echo json_encode([
                'success' => true,
                'message' => 'Menu item created successfully',
                'data' => ['id' => $item_id]
            ]);
            
        } else {
            // Get menu items
            $page = $_GET['page'] ?? 1;
            $limit = $_GET['limit'] ?? 20;
            $offset = ($page - 1) * $limit;
            
            $sql = "SELECT mi.*, mc.name as category_name 
                    FROM menu_items mi 
                    LEFT JOIN menu_categories mc ON mi.category_id = mc.id 
                    WHERE 1=1";
            $params = [];
            
            // Filter by category if specified
            if (isset($_GET['category_id'])) {
                $sql .= " AND mi.category_id = ?";
                $params[] = $_GET['category_id'];
            }
            
            // Filter by available status if specified
            if (isset($_GET['is_available'])) {
                $sql .= " AND mi.is_available = ?";
                $params[] = $_GET['is_available'];
            }
            
            $sql .= " ORDER BY mc.display_order, mi.name LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            
            $items = $db->fetchAll($sql, $params);
            
            // Get total count
            $count_sql = "SELECT COUNT(*) FROM menu_items WHERE 1=1";
            $count_params = [];
            
            if (isset($_GET['category_id'])) {
                $count_sql .= " AND category_id = ?";
                $count_params[] = $_GET['category_id'];
            }
            
            if (isset($_GET['is_available'])) {
                $count_sql .= " AND is_available = ?";
                $count_params[] = $_GET['is_available'];
            }
            
            $total = $db->fetchColumn($count_sql, $count_params);
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'items' => $items,
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $total,
                        'pages' => ceil($total / $limit)
                    ]
                ]
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleMenuItemDetails($user, $id) {
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            if (!authorize('menu.items.edit', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Update menu item
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No data provided'
                ]);
                return;
            }
            
            // Get current item data
            $current_item = $db->fetch("SELECT * FROM menu_items WHERE id = ?", [$id]);
            if (!$current_item) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Menu item not found'
                ]);
                return;
            }
            
            // Build update query
            $update_fields = [];
            $params = [];
            
            $allowed_fields = ['category_id', 'name', 'name_bn', 'description', 'description_bn', 'price', 'discount_price', 'image', 'preparation_time', 'is_spicy', 'is_available', 'is_popular', 'is_vegetarian', 'calories'];
            
            foreach ($allowed_fields as $field) {
                if (isset($data[$field])) {
                    $update_fields[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }
            
            // Update ingredients if provided
            if (isset($data['ingredients'])) {
                $update_fields[] = "ingredients = ?";
                $params[] = json_encode($data['ingredients']);
            }
            
            if (empty($update_fields)) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'No valid fields to update'
                ]);
                return;
            }
            
            $sql = "UPDATE menu_items SET " . implode(', ', $update_fields) . " WHERE id = ?";
            $params[] = $id;
            
            $db->execute($sql, $params);
            
            // Log activity
            logActivity($user['id'], 'menu_item_updated', 'Updated menu item: ' . $current_item['name'], 'menu_item', $id, $current_item, $data);
            
            echo json_encode([
                'success' => true,
                'message' => 'Menu item updated successfully'
            ]);
            
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            if (!authorize('menu.items.delete', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Delete menu item
            $current_item = $db->fetch("SELECT * FROM menu_items WHERE id = ?", [$id]);
            if (!$current_item) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Menu item not found'
                ]);
                return;
            }
            
            $db->execute("DELETE FROM menu_items WHERE id = ?", [$id]);
            
            // Log activity
            logActivity($user['id'], 'menu_item_deleted', 'Deleted menu item: ' . $current_item['name'], 'menu_item', $id, $current_item);
            
            echo json_encode([
                'success' => true,
                'message' => 'Menu item deleted successfully'
            ]);
            
        } else {
            // Get menu item details
            if (!authorize('menu.items.view', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            $item = $db->fetch(
                "SELECT mi.*, mc.name as category_name 
                 FROM menu_items mi 
                 LEFT JOIN menu_categories mc ON mi.category_id = mc.id 
                 WHERE mi.id = ?",
                [$id]
            );
            
            if (!$item) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Menu item not found'
                ]);
                return;
            }
            
            echo json_encode([
                'success' => true,
                'data' => $item
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleOrders($user) {
    if (!authorize('orders.view', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        // Get orders
        $page = $_GET['page'] ?? 1;
        $limit = $_GET['limit'] ?? 20;
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT o.*, b.name as branch_name, t.table_number, u.full_name as created_by_name 
                FROM orders o 
                LEFT JOIN branches b ON o.branch_id = b.id 
                LEFT JOIN tables t ON o.table_id = t.id 
                LEFT JOIN users u ON o.created_by = u.id 
                WHERE 1=1";
        $params = [];
        
        // Filter by branch if user is not super admin
        if ($user['role'] !== 'super_admin' && $user['branch_id']) {
            $sql .= " AND o.branch_id = ?";
            $params[] = $user['branch_id'];
        }
        
        // Filter by branch if specified
        if (isset($_GET['branch_id'])) {
            $sql .= " AND o.branch_id = ?";
            $params[] = $_GET['branch_id'];
        }
        
        // Filter by status if specified
        if (isset($_GET['status'])) {
            $sql .= " AND o.status = ?";
            $params[] = $_GET['status'];
        }
        
        // Filter by payment status if specified
        if (isset($_GET['payment_status'])) {
            $sql .= " AND o.payment_status = ?";
            $params[] = $_GET['payment_status'];
        }
        
        $sql .= " ORDER BY o.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $orders = $db->fetchAll($sql, $params);
        
        // Get order items for each order
        foreach ($orders as &$order) {
            $sql = "SELECT oi.*, mi.name_bn, mi.name, mi.preparation_time
                    FROM order_items oi 
                    LEFT JOIN menu_items mi ON oi.menu_item_id = mi.id 
                    WHERE oi.order_id = ?";
            $order['items'] = $db->fetchAll($sql, [$order['id']]);
        }
        
        // Get total count
        $count_sql = "SELECT COUNT(*) FROM orders WHERE 1=1";
        $count_params = [];
        
        if ($user['role'] !== 'super_admin' && $user['branch_id']) {
            $count_sql .= " AND branch_id = ?";
            $count_params[] = $user['branch_id'];
        }
        
        if (isset($_GET['branch_id'])) {
            $count_sql .= " AND branch_id = ?";
            $count_params[] = $_GET['branch_id'];
        }
        
        if (isset($_GET['status'])) {
            $count_sql .= " AND status = ?";
            $count_params[] = $_GET['status'];
        }
        
        if (isset($_GET['payment_status'])) {
            $count_sql .= " AND payment_status = ?";
            $count_params[] = $_GET['payment_status'];
        }
        
        $total = $db->fetchColumn($count_sql, $count_params);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'orders' => $orders,
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                ]
            ]
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleOrderStatusUpdate($user, $id) {
    if (!authorize('orders.status', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        // Update order status
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data || !isset($data['status'])) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => 'Status is required'
            ]);
            return;
        }
        
        // Get current order data
        $current_order = $db->fetch("SELECT * FROM orders WHERE id = ?", [$id]);
        if (!$current_order) {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'error' => 'Order not found'
            ]);
            return;
        }
        
        // Check if user has access to this order
        if ($user['role'] !== 'super_admin' && $user['branch_id'] && $current_order['branch_id'] != $user['branch_id']) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'error' => 'Access denied'
            ]);
            return;
        }
        
        // Update order status
        $db->execute("UPDATE orders SET status = ? WHERE id = ?", [$data['status'], $id]);
        
        // Log activity
        logActivity($user['id'], 'order_status_updated', 'Updated order status to: ' . $data['status'], 'order', $id, ['status' => $current_order['status']], ['status' => $data['status']]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Order status updated successfully'
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleSettings($user) {
    if (!authorize('system.settings.view', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            if (!authorize('system.settings.edit', $user['role'])) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'error' => 'Access denied'
                ]);
                return;
            }
            
            // Update system settings
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !is_array($data)) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Invalid settings data'
                ]);
                return;
            }
            
            foreach ($data as $key => $value) {
                // Check if setting exists and is editable
                $setting = $db->fetch("SELECT * FROM system_settings WHERE setting_key = ? AND is_editable = 1", [$key]);
                
                if ($setting) {
                    // Convert value based on type
                    switch ($setting['setting_type']) {
                        case 'boolean':
                            $value = $value ? '1' : '0';
                            break;
                        case 'number':
                            $value = (string) (int) $value;
                            break;
                        case 'json':
                        case 'array':
                            $value = json_encode($value);
                            break;
                        default:
                            $value = (string) $value;
                    }
                    
                    $db->execute(
                        "UPDATE system_settings SET setting_value = ?, updated_at = NOW() WHERE setting_key = ?",
                        [$value, $key]
                    );
                }
            }
            
            // Log activity
            logActivity($user['id'], 'settings_updated', 'Updated system settings', 'system_settings');
            
            echo json_encode([
                'success' => true,
                'message' => 'Settings updated successfully'
            ]);
            
        } else {
            // Get system settings
            $settings = $db->fetchAll("SELECT * FROM system_settings ORDER BY category, setting_key");
            
            // Group by category
            $grouped_settings = [];
            foreach ($settings as $setting) {
                $category = $setting['category'];
                if (!isset($grouped_settings[$category])) {
                    $grouped_settings[$category] = [];
                }
                
                // Convert value based on type
                switch ($setting['setting_type']) {
                    case 'boolean':
                        $setting['setting_value'] = $setting['setting_value'] === '1';
                        break;
                    case 'number':
                        $setting['setting_value'] = (int) $setting['setting_value'];
                        break;
                    case 'json':
                    case 'array':
                        $setting['setting_value'] = json_decode($setting['setting_value'], true);
                        break;
                }
                
                $grouped_settings[$category][] = $setting;
            }
            
            echo json_encode([
                'success' => true,
                'data' => $grouped_settings
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleAddons($user) {
    if (!authorize('system.addons.manage', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Install add-on
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['name']) || !isset($data['slug'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Missing required fields: name, slug'
                ]);
                return;
            }
            
            // Check if add-on already exists
            $existing_addon = $db->fetch("SELECT id FROM addons WHERE slug = ?", [$data['slug']]);
            if ($existing_addon) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Add-on already exists'
                ]);
                return;
            }
            
            $sql = "INSERT INTO addons (name, slug, version, description, author, website, type, category, status, dependencies, config_data, install_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'installed', ?, ?, NOW())";
            
            $params = [
                $data['name'],
                $data['slug'],
                $data['version'] ?? '1.0.0',
                $data['description'] ?? null,
                $data['author'] ?? null,
                $data['website'] ?? null,
                $data['type'] ?? 'module',
                $data['category'] ?? 'general',
                $data['dependencies'] ? json_encode($data['dependencies']) : null,
                $data['config_data'] ? json_encode($data['config_data']) : null
            ];
            
            $db->execute($sql, $params);
            $addon_id = $db->lastInsertId();
            
            // Log activity
            logActivity($user['id'], 'addon_installed', 'Installed add-on: ' . $data['name'], 'addon', $addon_id);
            
            echo json_encode([
                'success' => true,
                'message' => 'Add-on installed successfully',
                'data' => ['id' => $addon_id]
            ]);
            
        } else {
            // Get add-ons
            $addons = $db->fetchAll("SELECT * FROM addons ORDER BY category, name");
            
            echo json_encode([
                'success' => true,
                'data' => $addons
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleAddonToggle($user, $id) {
    if (!authorize('system.addons.manage', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        // Get current add-on data
        $addon = $db->fetch("SELECT * FROM addons WHERE id = ?", [$id]);
        if (!$addon) {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'error' => 'Add-on not found'
            ]);
            return;
        }
        
        // Toggle status
        $new_status = $addon['status'] === 'active' ? 'inactive' : 'active';
        
        $db->execute("UPDATE addons SET status = ? WHERE id = ?", [$new_status, $id]);
        
        // Log activity
        logActivity($user['id'], 'addon_toggled', 'Toggled add-on status: ' . $addon['name'] . ' to ' . $new_status, 'addon', $id, ['status' => $addon['status']], ['status' => $new_status]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Add-on status updated successfully',
            'data' => ['status' => $new_status]
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleThemes($user) {
    if (!authorize('system.themes.manage', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Install theme
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['name']) || !isset($data['slug'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Missing required fields: name, slug'
                ]);
                return;
            }
            
            // Check if theme already exists
            $existing_theme = $db->fetch("SELECT id FROM themes WHERE slug = ?", [$data['slug']]);
            if ($existing_theme) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => 'Theme already exists'
                ]);
                return;
            }
            
            $sql = "INSERT INTO themes (name, slug, version, description, author, website, screenshot, status, is_default, parent_theme, config_data, install_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'installed', ?, ?, ?, NOW())";
            
            $params = [
                $data['name'],
                $data['slug'],
                $data['version'] ?? '1.0.0',
                $data['description'] ?? null,
                $data['author'] ?? null,
                $data['website'] ?? null,
                $data['screenshot'] ?? null,
                $data['is_default'] ?? 0,
                $data['parent_theme'] ?? null,
                $data['config_data'] ? json_encode($data['config_data']) : null
            ];
            
            $db->execute($sql, $params);
            $theme_id = $db->lastInsertId();
            
            // Log activity
            logActivity($user['id'], 'theme_installed', 'Installed theme: ' . $data['name'], 'theme', $theme_id);
            
            echo json_encode([
                'success' => true,
                'message' => 'Theme installed successfully',
                'data' => ['id' => $theme_id]
            ]);
            
        } else {
            // Get themes
            $themes = $db->fetchAll("SELECT * FROM themes ORDER BY name");
            
            echo json_encode([
                'success' => true,
                'data' => $themes
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleThemeActivate($user, $id) {
    if (!authorize('system.themes.manage', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        // Get current theme data
        $theme = $db->fetch("SELECT * FROM themes WHERE id = ?", [$id]);
        if (!$theme) {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'error' => 'Theme not found'
            ]);
            return;
        }
        
        // Deactivate all other themes
        $db->execute("UPDATE themes SET status = 'inactive' WHERE id != ?", [$id]);
        
        // Activate this theme
        $db->execute("UPDATE themes SET status = 'active' WHERE id = ?", [$id]);
        
        // Log activity
        logActivity($user['id'], 'theme_activated', 'Activated theme: ' . $theme['name'], 'theme', $id);
        
        echo json_encode([
            'success' => true,
            'message' => 'Theme activated successfully'
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleFeatureFlags($user) {
    if (!authorize('system.features.manage', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        // Get feature flags
        $feature_flags = $db->fetchAll("SELECT * FROM feature_flags ORDER BY category, name");
        
        // Parse target_roles for each flag
        foreach ($feature_flags as &$flag) {
            if ($flag['target_roles']) {
                $flag['target_roles'] = json_decode($flag['target_roles'], true);
            } else {
                $flag['target_roles'] = [];
            }
            
            if ($flag['config_data']) {
                $flag['config_data'] = json_decode($flag['config_data'], true);
            } else {
                $flag['config_data'] = [];
            }
        }
        
        echo json_encode([
            'success' => true,
            'data' => $feature_flags
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleActivityLogs($user) {
    if (!authorize('system.logs.view', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        $page = $_GET['page'] ?? 1;
        $limit = $_GET['limit'] ?? 20;
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT al.*, u.full_name, u.username 
                FROM admin_activity_log al 
                LEFT JOIN users u ON al.user_id = u.id 
                WHERE 1=1";
        $params = [];
        
        // Filter by action if specified
        if (isset($_GET['action'])) {
            $sql .= " AND al.action = ?";
            $params[] = $_GET['action'];
        }
        
        // Filter by target_type if specified
        if (isset($_GET['target_type'])) {
            $sql .= " AND al.target_type = ?";
            $params[] = $_GET['target_type'];
        }
        
        // Filter by user_id if specified
        if (isset($_GET['user_id'])) {
            $sql .= " AND al.user_id = ?";
            $params[] = $_GET['user_id'];
        }
        
        $sql .= " ORDER BY al.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $logs = $db->fetchAll($sql, $params);
        
        // Parse old_values and new_values for each log
        foreach ($logs as &$log) {
            if ($log['old_values']) {
                $log['old_values'] = json_decode($log['old_values'], true);
            }
            if ($log['new_values']) {
                $log['new_values'] = json_decode($log['new_values'], true);
            }
        }
        
        // Get total count
        $count_sql = "SELECT COUNT(*) FROM admin_activity_log WHERE 1=1";
        $count_params = [];
        
        if (isset($_GET['action'])) {
            $count_sql .= " AND action = ?";
            $count_params[] = $_GET['action'];
        }
        
        if (isset($_GET['target_type'])) {
            $count_sql .= " AND target_type = ?";
            $count_params[] = $_GET['target_type'];
        }
        
        if (isset($_GET['user_id'])) {
            $count_sql .= " AND user_id = ?";
            $count_params[] = $_GET['user_id'];
        }
        
        $total = $db->fetchColumn($count_sql, $count_params);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'logs' => $logs,
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                ]
            ]
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleNotifications($user) {
    try {
        $db = Database::getInstance();
        
        $page = $_GET['page'] ?? 1;
        $limit = $_GET['limit'] ?? 20;
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM admin_notifications 
                WHERE (user_id = ? OR user_id IS NULL) 
                ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params = [$user['id'], $limit, $offset];
        
        $notifications = $db->fetchAll($sql, $params);
        
        // Get total count
        $total = $db->fetchColumn(
            "SELECT COUNT(*) FROM admin_notifications WHERE user_id = ? OR user_id IS NULL",
            [$user['id']]
        );
        
        // Get unread count
        $unread_count = $db->fetchColumn(
            "SELECT COUNT(*) FROM admin_notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0",
            [$user['id']]
        );
        
        echo json_encode([
            'success' => true,
            'data' => [
                'notifications' => $notifications,
                'unread_count' => $unread_count,
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $total,
                    'pages' => ceil($total / $limit)
                ]
            ]
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleNotificationRead($user, $id) {
    try {
        $db = Database::getInstance();
        
        // Get notification data
        $notification = $db->fetch("SELECT * FROM admin_notifications WHERE id = ?", [$id]);
        if (!$notification) {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'error' => 'Notification not found'
            ]);
            return;
        }
        
        // Check if user has access to this notification
        if ($notification['user_id'] && $notification['user_id'] != $user['id']) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'error' => 'Access denied'
            ]);
            return;
        }
        
        // Mark as read
        $db->execute("UPDATE admin_notifications SET is_read = 1 WHERE id = ?", [$id]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Notification marked as read'
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleBackups($user) {
    if (!authorize('system.backups.create', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Create backup
            $data = json_decode(file_get_contents('php://input'), true);
            
            $job_type = $data['type'] ?? 'full';
            
            // Create backup job
            $sql = "INSERT INTO backup_jobs (job_type, status, created_by) VALUES (?, 'pending', ?)";
            $db->execute($sql, [$job_type, $user['id']]);
            $job_id = $db->lastInsertId();
            
            // Log activity

            logActivity($user['id'], 'backup_created', 'Created backup job: ' . $job_type, 'backup_job', $job_id);
            
            echo json_encode([
                'success' => true,
                'message' => 'Backup job created successfully',
                'data' => ['id' => $job_id]
            ]);
            
        } else {
            // Get backup jobs
            $backups = $db->fetchAll("SELECT * FROM backup_jobs ORDER BY created_at DESC LIMIT 50");
            
            echo json_encode([
                'success' => true,
                'data' => $backups
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handlePermissions($user) {
    if (!authorize('superadmin.access', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        // Get all permissions
        $permissions = $db->fetchAll("SELECT * FROM admin_permissions ORDER BY category, name");
        
        // Get role permissions
        $role_permissions = $db->fetchAll("SELECT * FROM role_permissions ORDER BY role, permission_id");
        
        // Group permissions by category
        $grouped_permissions = [];
        foreach ($permissions as $permission) {
            $category = $permission['category'];
            if (!isset($grouped_permissions[$category])) {
                $grouped_permissions[$category] = [];
            }
            $grouped_permissions[$category][] = $permission;
        }
        
        // Group role permissions by role
        $grouped_role_permissions = [];
        foreach ($role_permissions as $rp) {
            if (!isset($grouped_role_permissions[$rp['role']])) {
                $grouped_role_permissions[$rp['role']] = [];
            }
            $grouped_role_permissions[$rp['role']][] = $rp['permission_id'];
        }
        
        echo json_encode([
            'success' => true,
            'data' => [
                'permissions' => $grouped_permissions,
                'role_permissions' => $grouped_role_permissions
            ]
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleStats($user) {
    if (!authorize('dashboard.stats', $user['role'])) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied'
        ]);
        return;
    }
    
    try {
        $db = Database::getInstance();
        
        $stats = [];
        
        // Basic counts
        $stats['total_branches'] = $db->fetchColumn("SELECT COUNT(*) FROM branches WHERE status = 'active'");
        $stats['total_users'] = $db->fetchColumn("SELECT COUNT(*) FROM users WHERE status = 'active'");
        $stats['total_menu_items'] = $db->fetchColumn("SELECT COUNT(*) FROM menu_items WHERE is_available = 1");
        $stats['total_orders'] = $db->fetchColumn("SELECT COUNT(*) FROM orders");
        
        // Today's stats
        $stats['orders_today'] = $db->fetchColumn("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()");
        $stats['revenue_today'] = $db->fetchColumn("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE DATE(created_at) = CURDATE() AND payment_status = 'paid'");
        
        // This week's stats
        $stats['orders_this_week'] = $db->fetchColumn("SELECT COUNT(*) FROM orders WHERE YEARWEEK(created_at) = YEARWEEK(NOW())");
        $stats['revenue_this_week'] = $db->fetchColumn("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE YEARWEEK(created_at) = YEARWEEK(NOW()) AND payment_status = 'paid'");
        
        // This month's stats
        $stats['orders_this_month'] = $db->fetchColumn("SELECT COUNT(*) FROM orders WHERE MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())");
        $stats['revenue_this_month'] = $db->fetchColumn("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW()) AND payment_status = 'paid'");
        
        // User counts by role
        $user_counts = $db->fetchAll("SELECT role, COUNT(*) as count FROM users WHERE status = 'active' GROUP BY role");
        $stats['user_counts'] = [];
        foreach ($user_counts as $count) {
            $stats['user_counts'][$count['role']] = $count['count'];
        }
        
        // Order status counts
        $order_status_counts = $db->fetchAll("SELECT status, COUNT(*) as count FROM orders GROUP BY status");
        $stats['order_status_counts'] = [];
        foreach ($order_status_counts as $count) {
            $stats['order_status_counts'][$count['status']] = $count['count'];
        }
        
        // Active add-ons and themes
        $stats['active_addons'] = $db->fetchColumn("SELECT COUNT(*) FROM addons WHERE status = 'active'");
        $stats['active_themes'] = $db->fetchColumn("SELECT COUNT(*) FROM themes WHERE status = 'active'");
        
        echo json_encode([
            'success' => true,
            'data' => $stats
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}