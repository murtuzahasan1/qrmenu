-- Admin System Tables for Luna-Dine
-- This file contains all new tables and columns needed for the admin panel

-- Enable foreign key constraints
SET FOREIGN_KEY_CHECKS = 0;

-- Admin Sessions Table
CREATE TABLE `admin_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_token` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `idx_sessions_user` (`user_id`),
  KEY `idx_sessions_token` (`session_token`),
  KEY `idx_sessions_expires` (`expires_at`),
  KEY `idx_sessions_active` (`is_active`),
  CONSTRAINT `admin_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin Permissions Table
CREATE TABLE `admin_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT 'general',
  `is_system` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_permissions_category` (`category`),
  KEY `idx_permissions_system` (`is_system`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Role Permissions Table
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(50) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_permission` (`role`, `permission_id`),
  KEY `idx_role_permissions_role` (`role`),
  KEY `idx_role_permissions_permission` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `admin_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin Activity Log Table
CREATE TABLE `admin_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activity_user` (`user_id`),
  KEY `idx_activity_action` (`action`),
  KEY `idx_activity_target` (`target_type`, `target_id`),
  KEY `idx_activity_created` (`created_at`),
  CONSTRAINT `admin_activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- System Settings Table
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `setting_type` enum('string','number','boolean','json','array') DEFAULT 'string',
  `category` varchar(50) DEFAULT 'general',
  `description` text DEFAULT NULL,
  `is_editable` tinyint(1) DEFAULT 1,
  `is_system` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_settings_category` (`category`),
  KEY `idx_settings_editable` (`is_editable`),
  KEY `idx_settings_system` (`is_system`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add-ons Table
CREATE TABLE `addons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `version` varchar(20) DEFAULT '1.0.0',
  `description` text DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `type` enum('module','plugin','extension','integration') DEFAULT 'module',
  `category` varchar(50) DEFAULT 'general',
  `status` enum('installed','active','inactive','disabled','error') DEFAULT 'installed',
  `is_system` tinyint(1) DEFAULT 0,
  `is_required` tinyint(1) DEFAULT 0,
  `dependencies` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `config_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `install_date` datetime DEFAULT NULL,
  `last_updated` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_addons_status` (`status`),
  KEY `idx_addons_type` (`type`),
  KEY `idx_addons_category` (`category`),
  KEY `idx_addons_system` (`is_system`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add-on Files Table
CREATE TABLE `addon_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addon_id` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` enum('php','js','css','sql','json','xml','other') DEFAULT 'php',
  `file_hash` varchar(64) DEFAULT NULL,
  `file_size` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_addon_files_addon` (`addon_id`),
  KEY `idx_addon_files_type` (`file_type`),
  KEY `idx_addon_files_active` (`is_active`),
  CONSTRAINT `addon_files_ibfk_1` FOREIGN KEY (`addon_id`) REFERENCES `addons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Themes Table
CREATE TABLE `themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `version` varchar(20) DEFAULT '1.0.0',
  `description` text DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `screenshot` varchar(255) DEFAULT NULL,
  `status` enum('installed','active','inactive','disabled','error') DEFAULT 'installed',
  `is_system` tinyint(1) DEFAULT 0,
  `is_default` tinyint(1) DEFAULT 0,
  `parent_theme` varchar(50) DEFAULT NULL,
  `config_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `install_date` datetime DEFAULT NULL,
  `last_updated` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_themes_status` (`status`),
  KEY `idx_themes_system` (`is_system`),
  KEY `idx_themes_default` (`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Theme Files Table
CREATE TABLE `theme_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `theme_id` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` enum('php','css','js','json','xml','image','other') DEFAULT 'css',
  `file_hash` varchar(64) DEFAULT NULL,
  `file_size` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_theme_files_theme` (`theme_id`),
  KEY `idx_theme_files_type` (`file_type`),
  KEY `idx_theme_files_active` (`is_active`),
  CONSTRAINT `theme_files_ibfk_1` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Feature Flags Table
CREATE TABLE `feature_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT 1,
  `category` varchar(50) DEFAULT 'general',
  `target_roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `config_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_feature_flags_enabled` (`is_enabled`),
  KEY `idx_feature_flags_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin Notifications Table
CREATE TABLE `admin_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `type` enum('info','success','warning','error','system') DEFAULT 'info',
  `title` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `action_url` varchar(255) DEFAULT NULL,
  `action_text` varchar(100) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `is_dismissed` tinyint(1) DEFAULT 0,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`),
  KEY `idx_notifications_type` (`type`),
  KEY `idx_notifications_read` (`is_read`),
  KEY `idx_notifications_created` (`created_at`),
  CONSTRAINT `admin_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Backup Jobs Table
CREATE TABLE `backup_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_type` enum('full','database','files','config') DEFAULT 'full',
  `status` enum('pending','running','completed','failed','cancelled') DEFAULT 'pending',
  `file_path` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_backup_jobs_status` (`status`),
  KEY `idx_backup_jobs_type` (`job_type`),
  KEY `idx_backup_jobs_created` (`created_at`),
  CONSTRAINT `backup_jobs_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- System Logs Table
CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` enum('debug','info','notice','warning','error','critical','alert','emergency') DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `channel` varchar(50) DEFAULT 'system',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_logs_level` (`level`),
  KEY `idx_logs_channel` (`channel`),
  KEY `idx_logs_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default permissions
INSERT INTO `admin_permissions` (`name`, `code`, `description`, `category`, `is_system`) VALUES
-- Dashboard permissions
('View Dashboard', 'dashboard.view', 'Access to admin dashboard', 'dashboard', 1),
('View Statistics', 'dashboard.stats', 'View system statistics and analytics', 'dashboard', 1),

-- User management permissions
('View Users', 'users.view', 'View list of users', 'users', 1),
('Create Users', 'users.create', 'Create new users', 'users', 1),
('Edit Users', 'users.edit', 'Edit existing users', 'users', 1),
('Delete Users', 'users.delete', 'Delete users', 'users', 1),
('Manage User Roles', 'users.roles', 'Manage user roles and permissions', 'users', 1),

-- Branch management permissions
('View Branches', 'branches.view', 'View list of branches', 'branches', 1),
('Create Branches', 'branches.create', 'Create new branches', 'branches', 1),
('Edit Branches', 'branches.edit', 'Edit existing branches', 'branches', 1),
('Delete Branches', 'branches.delete', 'Delete branches', 'branches', 1),

-- Menu management permissions
('View Menu Categories', 'menu.categories.view', 'View menu categories', 'menu', 1),
('Create Menu Categories', 'menu.categories.create', 'Create new menu categories', 'menu', 1),
('Edit Menu Categories', 'menu.categories.edit', 'Edit menu categories', 'menu', 1),
('Delete Menu Categories', 'menu.categories.delete', 'Delete menu categories', 'menu', 1),
('View Menu Items', 'menu.items.view', 'View menu items', 'menu', 1),
('Create Menu Items', 'menu.items.create', 'Create new menu items', 'menu', 1),
('Edit Menu Items', 'menu.items.edit', 'Edit menu items', 'menu', 1),
('Delete Menu Items', 'menu.items.delete', 'Delete menu items', 'menu', 1),

-- Order management permissions
('View Orders', 'orders.view', 'View orders', 'orders', 1),
('Create Orders', 'orders.create', 'Create new orders', 'orders', 1),
('Edit Orders', 'orders.edit', 'Edit orders', 'orders', 1),
('Delete Orders', 'orders.delete', 'Delete orders', 'orders', 1),
('Manage Order Status', 'orders.status', 'Update order status', 'orders', 1),

-- System management permissions
('View System Settings', 'system.settings.view', 'View system settings', 'system', 1),
('Edit System Settings', 'system.settings.edit', 'Edit system settings', 'system', 1),
('View Activity Logs', 'system.logs.view', 'View system activity logs', 'system', 1),
('Manage Add-ons', 'system.addons.manage', 'Manage system add-ons', 'system', 1),
('Manage Themes', 'system.themes.manage', 'Manage system themes', 'system', 1),
('Manage Feature Flags', 'system.features.manage', 'Manage feature flags', 'system', 1),
('Create Backups', 'system.backups.create', 'Create system backups', 'system', 1),
('Restore Backups', 'system.backups.restore', 'Restore system backups', 'system', 1),

-- Super admin permissions
('Super Admin Access', 'superadmin.access', 'Full system access (Super Admin only)', 'system', 1),
('Manage System', 'superadmin.system', 'Manage entire system (Super Admin only)', 'system', 1),
('View Hidden Users', 'superadmin.hidden', 'View hidden super admin users', 'system', 1);

-- Insert default role permissions
INSERT INTO `role_permissions` (`role`, `permission_id`) VALUES
-- Super Admin gets all permissions
('super_admin', 1), ('super_admin', 2), ('super_admin', 3), ('super_admin', 4), ('super_admin', 5), 
('super_admin', 6), ('super_admin', 7), ('super_admin', 8), ('super_admin', 9), ('super_admin', 10), 
('super_admin', 11), ('super_admin', 12), ('super_admin', 13), ('super_admin', 14), ('super_admin', 15), 
('super_admin', 16), ('super_admin', 17), ('super_admin', 18), ('super_admin', 19), ('super_admin', 20), 
('super_admin', 21), ('super_admin', 22), ('super_admin', 23), ('super_admin', 24), ('super_admin', 25), 
('super_admin', 26), ('super_admin', 27), ('super_admin', 28), ('super_admin', 29), ('super_admin', 30), 
('super_admin', 31), ('super_admin', 32),

-- Owner permissions
('owner', 1), ('owner', 2), ('owner', 3), ('owner', 4), ('owner', 5), ('owner', 6), 
('owner', 7), ('owner', 8), ('owner', 9), ('owner', 10), ('owner', 11), ('owner', 12), 
('owner', 13), ('owner', 14), ('owner', 15), ('owner', 16), ('owner', 17), ('owner', 18), 
('owner', 19), ('owner', 20), ('owner', 21), ('owner', 22), ('owner', 23), ('owner', 24), 
('owner', 25), ('owner', 26), ('owner', 27), ('owner', 28), ('owner', 29), ('owner', 30),

-- Manager permissions
('manager', 1), ('manager', 2), ('manager', 3), ('manager', 4), ('manager', 5), ('manager', 6), 
('manager', 7), ('manager', 8), ('manager', 9), ('manager', 10), ('manager', 11), ('manager', 12), 
('manager', 13), ('manager', 14), ('manager', 15), ('manager', 16), ('manager', 17), ('manager', 18), 
('manager', 19), ('manager', 20), ('manager', 21), ('manager', 22), ('manager', 23), ('manager', 24),

-- Branch Manager permissions
('branch_manager', 1), ('branch_manager', 2), ('branch_manager', 3), ('branch_manager', 4), 
('branch_manager', 9), ('branch_manager', 10), ('branch_manager', 11), ('branch_manager', 12), 
('branch_manager', 13), ('branch_manager', 14), ('branch_manager', 15), ('branch_manager', 16), 
('branch_manager', 17), ('branch_manager', 18), ('branch_manager', 19), ('branch_manager', 20), 
('branch_manager', 21), ('branch_manager', 22), ('branch_manager', 23), ('branch_manager', 24),

-- Chef permissions
('chef', 1), ('chef', 2), ('chef', 9), ('chef', 10), ('chef', 11), ('chef', 12), 
('chef', 13), ('chef', 14), ('chef', 15), ('chef', 16), ('chef', 17), ('chef', 18), 
('chef', 19), ('chef', 20), ('chef', 21), ('chef', 22), ('chef', 23), ('chef', 24),

-- Waiter permissions
('waiter', 1), ('waiter', 2), ('waiter', 9), ('waiter', 10), ('waiter', 11), ('waiter', 12), 
('waiter', 13), ('waiter', 14), ('waiter', 15), ('waiter', 16), ('waiter', 17), ('waiter', 18), 
('waiter', 19), ('waiter', 20), ('waiter', 21), ('waiter', 22), ('waiter', 23), ('waiter', 24),

-- Restaurant Staff permissions
('restaurant_staff', 1), ('restaurant_staff', 2), ('restaurant_staff', 9), ('restaurant_staff', 10), 
('restaurant_staff', 11), ('restaurant_staff', 12), ('restaurant_staff', 13), ('restaurant_staff', 14), 
('restaurant_staff', 15), ('restaurant_staff', 16), ('restaurant_staff', 17), ('restaurant_staff', 18), 
('restaurant_staff', 19), ('restaurant_staff', 20), ('restaurant_staff', 21), ('restaurant_staff', 22), 
('restaurant_staff', 23), ('restaurant_staff', 24);

-- Insert default system settings
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_editable`, `is_system`) VALUES
('site_name', 'Luna-Dine Restaurant', 'string', 'general', 'Website name', 1, 0),
('site_description', 'Digital Restaurant Menu System', 'string', 'general', 'Website description', 1, 0),
('admin_email', 'admin@lunadine.com', 'string', 'general', 'Admin email address', 1, 0),
('contact_phone', '+8801234567890', 'string', 'general', 'Contact phone number', 1, 0),
('contact_address', '123 Restaurant Street, Dhaka, Bangladesh', 'string', 'general', 'Contact address', 1, 0),
('currency', 'BDT', 'string', 'general', 'Default currency', 1, 0),
('currency_symbol', '৳', 'string', 'general', 'Currency symbol', 1, 0),
('timezone', 'Asia/Dhaka', 'string', 'general', 'System timezone', 1, 1),
('date_format', 'd/m/Y', 'string', 'general', 'Date format', 1, 0),
('time_format', 'h:i A', 'string', 'general', 'Time format', 1, 0),
('items_per_page', '20', 'number', 'general', 'Items per page in lists', 1, 0),
('session_timeout', '7200', 'number', 'security', 'Session timeout in seconds', 1, 0),
('max_login_attempts', '5', 'number', 'security', 'Maximum login attempts', 1, 0),
('lockout_time', '300', 'number', 'security', 'Account lockout time in seconds', 1, 0),
('enable_2fa', '0', 'boolean', 'security', 'Enable two-factor authentication', 1, 0),
('enable_notifications', '1', 'boolean', 'notifications', 'Enable admin notifications', 1, 0),
('notification_email', '1', 'boolean', 'notifications', 'Enable email notifications', 1, 0),
('backup_auto_enabled', '0', 'boolean', 'backup', 'Enable automatic backups', 1, 0),
('backup_frequency', 'daily', 'string', 'backup', 'Backup frequency', 1, 0),
('backup_retention', '30', 'number', 'backup', 'Backup retention days', 1, 0),
('maintenance_mode', '0', 'boolean', 'system', 'Maintenance mode', 1, 0),
('debug_mode', '0', 'boolean', 'system', 'Debug mode', 1, 0),
('log_level', 'info', 'string', 'system', 'Log level', 1, 0),
('max_file_size', '10485760', 'number', 'upload', 'Maximum file size for uploads', 1, 0),
('allowed_file_types', 'jpg,jpeg,png,gif,pdf', 'string', 'upload', 'Allowed file types', 1, 0),
('api_rate_limit', '100', 'number', 'api', 'API rate limit per minute', 1, 0),
('api_timeout', '30', 'number', 'api', 'API timeout in seconds', 1, 0);

-- Insert default feature flags
INSERT INTO `feature_flags` (`name`, `code`, `description`, `is_enabled`, `category`, `target_roles`) VALUES
('Online Ordering', 'online_ordering', 'Enable online ordering system', 1, 'ordering', '["owner","manager","branch_manager","waiter","restaurant_staff"]'),
('Table Reservation', 'table_reservation', 'Enable table reservation system', 1, 'reservation', '["owner","manager","branch_manager","waiter","restaurant_staff"]'),
('Delivery System', 'delivery_system', 'Enable delivery system', 0, 'delivery', '["owner","manager","branch_manager"]'),
('Customer Feedback', 'customer_feedback', 'Enable customer feedback system', 1, 'feedback', '["owner","manager","branch_manager","waiter","restaurant_staff"]'),
('Loyalty Program', 'loyalty_program', 'Enable customer loyalty program', 0, 'marketing', '["owner","manager"]'),
('SMS Notifications', 'sms_notifications', 'Enable SMS notifications', 0, 'notifications', '["owner","manager"]'),
('Email Marketing', 'email_marketing', 'Enable email marketing', 0, 'marketing', '["owner","manager"]'),
('Analytics Dashboard', 'analytics_dashboard', 'Enable analytics dashboard', 1, 'analytics', '["owner","manager","branch_manager"]'),
('Inventory Management', 'inventory_management', 'Enable inventory management', 0, 'inventory', '["owner","manager","branch_manager","chef"]'),
('Staff Management', 'staff_management', 'Enable staff management', 1, 'hr', '["owner","manager","branch_manager"]'),
('Multi-language', 'multilingual', 'Enable multi-language support', 1, 'localization', '["owner","manager","branch_manager"]'),
('Mobile App', 'mobile_app', 'Enable mobile app features', 0, 'mobile', '["owner","manager"]'),
('QR Code Menu', 'qr_menu', 'Enable QR code menu system', 1, 'menu', '["owner","manager","branch_manager","waiter","restaurant_staff"]'),
('Payment Gateway', 'payment_gateway', 'Enable payment gateway integration', 0, 'payment', '["owner","manager"]'),
('Tax Management', 'tax_management', 'Enable tax management', 1, 'finance', '["owner","manager","branch_manager"]');

-- Re-enable foreign key constraints
SET FOREIGN_KEY_CHECKS = 1;